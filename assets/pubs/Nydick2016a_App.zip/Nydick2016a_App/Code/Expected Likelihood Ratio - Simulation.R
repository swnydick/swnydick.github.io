####################
# ELR Simulation   #
#                  #
# Steven W. Nydick #
# 2015-11-15       #
####################

require(plyr)
require(dplyr)
require(magrittr)
require(openxlsx)
require(WriteXLS)

# Outer directory (parent of simulation)
outer_dir <- "/Users/stevennydick/Documents/School, Work, and Expense/Research/Nydick - Expected Likelihood Ratio"

###########################
# 1. Loading Files into R #
###########################

# Code directory (with all simulation code) AND package directory
code_dir    <- "Expected Likelihood Ratio - R Code"
package_dir <- "catIrt"
full_dir    <- paste(outer_dir, code_dir, package_dir, sep = "/")

# Loading ALL .so files

so_expr <-  ~sapply(dir(path    = full_dir,
                        pattern = "\\.so$",
                        recursive = TRUE, full.names = TRUE),
                    dyn.load)
eval(so_expr[[2]])

# Loading ALL .R files
rr_expr <- ~sapply(dir(path    = full_dir,
                       pattern = "\\.[rR]$",
                       recursive = TRUE, full.names = TRUE),
                   source)
eval(rr_expr[[2]])

#####################
# 2. Misc Functions #
#####################

#~~~~~~~~~~~~~~~~~~~~#
# Parallel Functions #
#~~~~~~~~~~~~~~~~~~~~#

parCat <- function(ps, nps,
                   cond,
                   thetas, params){
  
#####
# A # (SPECIFYING PROCESSOR THETAS)
#####
  
  # N is the total number of simulees
  N <- length(thetas)
  
  # thetas_ps is the thetas for the current processor 
  if(N %% nps == 0){
    thetas_ps <- thetas[(N/nps * (ps - 1) + 1):(N/nps * ps)]
  } else{
    thetas_ps <- thetas[cut(1:N, nps, 1:nps, right = FALSE) == ps]
  } # END ifelse STATEMENT
  
#####
# B # (EXTRACTING OTHER PARTS OF SIMULATION)
#####
  
  # extracting the parameters/bound/select
  params_i <- params[[cond$par_cond]]
  bound_i  <- cond$bound
  select_i <- switch(as.character(cond$select),
                     `FI-bound`            = list(select = "UW-FI",      at = "bounds"),
                     `FI-ability`          = list(select = "UW-FI",      at = "theta"),
                     `FI-middle`           = list(select = "UW-FIM",     at = "bounds"),
                     `KL-bound`            = list(select = "FP-KL",      at = "bounds"),
                     `KL-estimated`        = list(select = "FP-EKL",     at = "bounds"),
                     `ELR`                 = list(select = "FP-ELR",     at = "bounds"),
                     `FI-ability-hybrid`   = list(select = "MX-FI/ELR",  at = "theta"),
                     `KL-estimated-hybrid` = list(select = "MX-EKL/ELR", at = "bounds"))
  
  # fixed stuff (delta and mx_sem)
  delta  <- 0.1
  mx_sem <- 0.5
  alpha  <- beta <- .05
  
#####
# B # (RUNNING MODEL AND RETURNING)
#####
  
  ret  <- catIrt(params = params_i,
                 mod = "brm", theta = thetas_ps,
                 catStart  = list(n.start = 5, init.theta = 0,
                                  select = select_i$select, at = select_i$at,
                                  n.select = 1, delta = delta,
                                  score = "step", step.size = 1,
                                  range = c(-6, 6),
                                  mx_sem = mx_sem,
                                  leave.after.MLE = FALSE),
                 catMiddle = list(select = select_i$select, at = select_i$at,
                                  n.select = 1, delta = delta,
                                  score = "MLE",
                                  range = c(-6, 6),
                                  mx_sem = mx_sem),
                 catTerm   = list(term = "class", score = "MLE",
                                  n.min = 5, n.max = 200,
                                  c.term = list(method = "SPRT",
                                                bounds = bound_i,
                                                categ = c(0, 1),
                                                delta = delta,
                                                alpha = alpha, beta = beta)), progress = FALSE)
  
  return(ret)                                
  
} # END parCat FUNCTION


parCollect <- function(ret){
  
  out <- NULL
  
  for(i in seq_along(ret[[1]])){
    
    # pull out names/values for place "i"
    name_i <- names(ret[[1]])[i]
    vals_i <- lapply(ret, "[[", name_i)
    
    # either keep index 1, bind by rbind, or bind by vector
    if( name_i %in% c("cat_indiv", "it_select") ){
      next
    } else if( name_i %in% c("mod", "full_params") ){
      vals_i <- vals_i[[1]]
    } else if( is.matrix(vals_i[[1]]) | is.data.frame(vals_i[[1]]) ){
      vals_i <- do.call(rbind, vals_i)
    } else{
      vals_i <- do.call(c, vals_i)
    } # END ifelse STATEMENT
    
    # add to that name of out
    out[[name_i]] <- vals_i
    
  } # END for i LOOP
  
  # return the whole thing!
  return(out)
  
} # END parCollect FUNCTION


#################################################
# 3. Simulation: Checking FI, KL, and ELR, etc. #
#################################################

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Constructing Item Sets and Persons #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

## DIRECTORY ##
setwd(dir(path = outer_dir, pattern = "Data", full.names = TRUE)[1])
setwd(max(dir()))

## PERSONS ##
set.seed(982343)
N      <- 10000
thetas <- rnorm(N)

## ITEMS ##
set.seed(632452)

# conditions for parameters
par_bpar <- c("flat", "moderate", "peaked")
par_cpar <- sprintf("%.2f", c(0.25, 0.00)) %>%
            c("random")
par_size <- c(750, 1500)
par_cond <- expand.grid(par_bpar = par_bpar,
                        par_cpar = par_cpar,
                        par_size = par_size,
                        stringsAsFactors = FALSE) %>%
            mutate(par_cond = paste0(par_bpar, "_", par_cpar, "_", par_size))

# list to store parameters
params   <- vector(mode = "list", length = nrow(par_cond)) %>% 
            setNames(par_cond$par_cond)

# generating parameters for each condition
for(i in 1:nrow(par_cond)){
  
  par_cond_i <- par_cond[i, ]
  par_bpar_i <- par_cond_i$par_bpar # the bpar dist (flat, peaked, moderate)
  par_cpar_i <- par_cond_i$par_cpar # the cpar dist
  par_size_i <- par_cond_i$par_size # the size (500, 1000, 2000)
  
  # similar to my earlier simulation
  as <- rlnorm(n = par_size_i,
               meanlog = .38, sdlog = .25)
  
# --> b-parameters (set by bpar)
  if(par_bpar_i == "flat"){
    
    # if par_bpar is flat, b is uniform
    bs <- runif(n = par_size_i,
                min = -4, max = 4)
    
  } else{
    
    b_mn <- 0
    b_sd <- switch(par_bpar_i,
                   moderate = 1.500,
                   peaked   = 0.707)
    
    # if par_bpar is peaked/moderate, b is normal
    bs <- rnorm(n = par_size_i,
                mean = b_mn, sd = b_sd)
    
  } # END ifelse STATEMENT
  
# --> c-parameters (set by cpar)
  if(par_cpar_i == "random"){
    
    # if par_cpar is random, c is randomly generated
    # --> mean of the beta is .20
    # --> sd of the beta is .04
    cs <- rbeta(n = par_size_i,
                shape1 = 19.8, shape2 = 79.2)
    
    # beta with mean of .20 and sd of .04
    
  } else{
    cs <- rep(as.numeric(par_cpar_i), par_size_i)
  } # END ifelse STATEMENT
  
  params[[i]] <- cbind(as, bs, cs)
    
} # END for i LOOP


#~~~~~~~~~~~~~~~~~~~~~~~#
# Generating Conditions #
#~~~~~~~~~~~~~~~~~~~~~~~#

cond_select <- c("FI-bound",
                 "FI-ability",
                 "FI-middle",
                 "KL-bound",
                 "KL-estimated",
                 "ELR",
                 "FI-ability-hybrid",
                 "KL-estimated-hybrid")

cond_bound <- seq(-3.0, 3.0, 1.0)

cond <- expand.grid(select = cond_select,
                    bound  = cond_bound,
                    stringsAsFactors = TRUE) %>%
        merge(par_cond, ., by = NULL)

numb <- lapply(seq_along(cond) %>% setNames(names(cond)),
               FUN = function(i){
                 x <- cond[ , i]
                 match(x, unique(x))
               }) %>%
        do.call(data.frame, .) %>%
        select(-matches("par_cond"))


#~~~~~~~~~~~~~~~~~~~~#
# Running Simulation #
#~~~~~~~~~~~~~~~~~~~~#

# set up libraries to run on cluster
library(snow)
library(Rmpi)
library(rlecuyer)

# set up a certain number of clusters:
nps <- 7
cl  <- makeCluster(spec = nps, type = "SOCK")

# load libraries on the clusters:
invisible(clusterExport(cl, list = ls()))
invisible(clusterEvalQ(cl,  eval(so_expr[[2]])))
invisible(clusterEvalQ(cl,  library(numDeriv)))
invisible(clusterEvalQ(cl,  library(sfsmisc)))
invisible(clusterEvalQ(cl,  library(rlecuyer)))

set.seed(4532452)
seed <- round(runif(n = nrow(numb)) * 1000000)

for(i in 1:nrow(cond)){

  # setting up the random number generator:
  clusterSetupRNG(cl, type = "RNGstream", seed = seed[i])
  
  # running catMirt on a certain number of thetas on each cluster:
  out <- clusterApply(cl = cl, x = 1:nps, fun = parCat,
                      nps = nps, cond = cond[i, ],
                      thetas = thetas,
                      params = params) %>%
         parCollect

  # saving the output to a file:
  save(out, file = paste("sim", paste(numb[i, ], collapse = ""), ".Rdata", sep = ""))

  cat("Finished iters: ", i, ": ", Sys.time(), "\n", sep = "")
 
  # and cleaning up: 
  rm(out)
     
 } # END for i LOOP
 
stopCluster(cl)


########################
# 4. Analyzing Results #
########################

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Functions for Analyzing Data #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

# calculates kappa = (p0 - pc)/(1 - pc) given sample and population values
calc_kappa <- function(samp, pop){
  p0 <- mean(samp == pop)
  pc <- sum(prop.table(table(pop))^2)
  
  (p0 - pc)/(1 - pc)
} # END calc_kappa FUNCTION

# calculates conditional pcc given population value of 'val'
calc_cond_pcc <- function(samp, pop, val = 0){
  sum(samp == val & pop == val) / sum(pop == val)
} # END calc_cond_pcc

cond_app <- apply(numb, 1, paste, collapse = "")

#~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Calculating Results Table #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~#

# calculate results for all conditions in list form
results  <- lapply(seq_along(cond_app),
                   FUN = function(i){
                     load(dir(pattern = cond_app[i]))
                     
                     # theta intervals
                     theta_int <- out$true_theta %>%
                                  cut(., breaks = c(range(.), seq(-2, 2, by = .2)),
                                      include.lowest = TRUE)
                     
                     # data.frame including theta intervals
                     theta_df  <- data.frame(theta_int  = theta_int,
                                             cat_length = out$cat_length,
                                             cat_categ  = out$cat_categ,
                                             true_categ = out$true_categ)
                     
                     # removing the overall parameter condition and calculating overall stats
                     res_overall <- cond[i, ] %>%
                                    mutate_(avg_length = ~mean(out$cat_length),
                                            pcc        = ~mean(out$cat_categ == out$true_categ),
                                            kappa      = ~calc_kappa(out$cat_categ, out$true_categ),
                                            loss_100   = ~100 * (1 - pcc) + avg_length,
                                            loss_500   = ~500 * (1 - pcc) + avg_length,
                                            pcc_low    = ~calc_cond_pcc(out$cat_categ, out$true_categ, 0),
                                            pcc_high   = ~calc_cond_pcc(out$cat_categ, out$true_categ, 1))
                     
                     # calculating conditional stats
                     res_cond    <- group_by(theta_df, theta_int) %>%
                                    summarize_(N          = ~n(),
                                               avg_length = ~mean(cat_length),
                                               pcc        = ~mean(cat_categ == true_categ),
                                               loss_100   = ~100 * (1 - pcc) + avg_length,
                                               loss_500   = ~500 * (1 - pcc) + avg_length) %>%
                                    cbind(cond[i, ], .)
                     
                     list(overall = res_overall, conditional = res_cond)
                       
                   })

# bind and organize overall and conditional data.frames
results <- lapply(names(results[[1]]) %>% setNames(., .),
                  FUN = function(nm){
                    lapply(results, "[[", nm) %>%
                    bind_rows %>%
                    as.data.frame %>%
            
                    # arrange results so that select is nested within every other cond.
                    arrange_(.dots = setdiff(names(cond), "select")) %>%
                    mutate(select = factor(select, levels = unique(select)))
                  })

# write results to a file/files
WriteXLS("results", "simulation results.xlsx",
         AutoFilter = TRUE)
save(results, file = "simulation results.Rdata")

#~~~~~~~~~~~~~~~~~~~~~~~~~#
# Graphics for NCME/Paper #
#~~~~~~~~~~~~~~~~~~~~~~~~~#

# Graphics Directory
setwd(dir(path = outer_dir, pattern = "Figures", full.names = TRUE)[1])

cols <- c("cyan", "magenta",
          "chartreuse", "gold",
          "grey45", "blue", "red",
          "forestgreen", "chocolate4", "black")
pchs <- rep(15:20, 2)


#####
# 1 # Demonstration of FI-middle
#####

# - this is to demonstrate FI-middle improving on FI-bound/FI-ability if c = 0.
# - each graph uses bpar = flat, cpar = 0.00, and size = 750 (or 1500?)
# - the "added on graph" is bold (lwd = 4), the others are normal (lwd = 2)

# Make three graphs:
#  1) FI-bound added on across classification bounds (normal)
#  2) FI-ability added on across classification bounds (not-recommended)
#  3) FI-middle added on across classification bounds (improves)

sel_cond  <- list(c("FI-bound"),
                  c("FI-bound", "FI-ability"),
                  c("FI-bound", "FI-ability", "FI-middle"))
oth_cond  <- c(~par_bpar == "flat",
               ~par_cpar == "0.00" | par_cpar == 0,
               ~par_size == 750)

inner_dir <- "1Intro"

dir.create(inner_dir, showWarnings = FALSE)
setwd(inner_dir)

for(sel in sel_cond){
  all_cond  <- c(~select %in% sel, oth_cond)
  results_s <- filter_(results$overall,
                       .dots = all_cond)
  
  pdf(file = paste0("Graphics_-_1Intro_", paste(sel, collapse = "_"), "-ATL.pdf"),
      width = 8, height = 6)

  with(results_s,{
       plot(x = bound, y = avg_length, type = "p",
            ylim = c(0, 60),
            xlab = expression(theta[0]), ylab = "Average Test Length",
            main = "",
            pch  = pchs[as.numeric(select)],
            col  = cols[as.numeric(select)],
            cex = 1.2, lwd = 2, axes = FALSE)
       axis(1, col = "grey", at = unique(bound))
       axis(2, col = "grey", las = 1)
       legend(x = "topright",
              legend = unique(select),
              pch    = pchs[unique(as.numeric(select))],
              col    = cols[unique(as.numeric(select))],
              cex    = 1,
              bty    = "n")
       })
  
  dev.off()
  
  pdf(file = paste0("Graphics_-_1Intro_", paste(sel, collapse = "_"), "-PCC.pdf"),
      width = 8, height = 6)
  
  with(results_s,{
    plot(x = bound, y = 1 - pcc, type = "p",
         ylim = c(0, .055),
         xlab = expression(theta[0]), ylab = "Percent Misclassified",
         main = "",
         pch  = pchs[as.numeric(select)],
         col  = cols[as.numeric(select)],
         cex = 1.2, lwd = 2, axes = FALSE)
    axis(1, col = "grey", at = unique(bound))
    axis(2, col = "grey", las = 1)
    legend(x = "topleft",
           legend = unique(select),
           pch    = pchs[unique(as.numeric(select))],
           col    = cols[unique(as.numeric(select))],
           cex    = 1,
           bty    = "n")
  })
  
  dev.off()
} # END for sel LOOP

setwd("..")


#####
# 2 # Overall Graphs of All Conditions
#####

# selection algorithms to use
# sel_cond  <- setdiff(unique(cond$select), "FI-middle")
sel_cond <- grep(x       = unique(cond$select),
                 pattern = "^KL",
                 value   = TRUE,
                 invert  = TRUE)

# everything but selection algorithms and bounds (corresponding numbers)
all_cond  <- cond[setdiff(names(cond),
                          c("select", "bound"))] %>%
             unique

# the appendix number (conditional number)
oth_app   <- numb[intersect(names(numb), names(all_cond))] %>%
             unique %>%
             apply(1, paste, collapse = "")

# the header indicating bank conditions
oth_head   <- all_cond[setdiff(names(all_cond), "par_cond")]
oth_head[] <- lapply(oth_head, as.character)
oth_head   <- oth_head %>%
              setNames(gsub(pattern = ".*_(.*?)(par)*$",
                            replace = "\\1",
                            x = names(.),
                            perl = TRUE)) %>%
              apply(1,
                    FUN = function(x){
                      paste(names(.), x, sep = " = ", collapse = "; ")
                    })

# turning oth_cond into a formula to use with "select"
oth_cond  <- lapply(1:nrow(all_cond),
                    FUN = function(i){
                      paste0("~", names(all_cond), "=='", all_cond[i, ], "'") %>%
                      lapply(as.formula)
                    })

inner_dir <- "2Results-All-Present"

dir.create(inner_dir, showWarnings = FALSE)
setwd(inner_dir)

for(i in seq_along(oth_cond)){
  red_cond  <- c(~select %in% sel_cond,
                 oth_cond[[i]])
  all_cond  <- c(~select %in% unique(cond$select),
                 oth_cond[[i]])
  all_app   <- oth_app[i]
  
  results_a <- filter_(results$overall,
                       .dots = all_cond)
  results_s <- filter_(results$overall,
                       .dots = red_cond) %>%
               merge(., ddply(results_a, "bound", summarize,
                              med_avg_length = median(avg_length),
                              med_pcc        = median(pcc))) %>%
               rbind(.[.$select %in% c("ELR"), ])
  
  pdf(file = paste0("Graphics_-_", inner_dir, "_", all_app, "-ATL.pdf"),
      width = 8, height = 6)
  
  # 1a. Plotting Average Test Length Deviance #
  with(results_s,{
    plot(x = bound, y = avg_length - med_avg_length, type = "p",
         ylim = c(-10, 5),
         xlab = expression(theta[0]), ylab = "Average Test Length Deviance",
         main = "",
         pch  = pchs[as.numeric(select)],
         col  = cols[as.numeric(select)],
         cex = 1.5, lwd = 2, axes = FALSE)
    abline(h = 0, lty = 2, lwd = 2, col = "lightgrey")
    axis(1, col = "grey", at = unique(bound))
    axis(2, col = "grey", las = 1)
    mtext(oth_head[i])
    legend(x = "bottomleft", ncol = 2,
           legend = intersect(levels(select), unique(select)),
           pch    = pchs[which(levels(select) %in% unique(select))],
           col    = cols[which(levels(select) %in% unique(select))],
           cex    = 1,
           bty    = "n")
  })
  
  # 1b. Overlaying with Lines #
  for(sel in unique(results_s$select)){
    results_si <- subset(results_s, select == sel) %>%
                  unique %>%
                  arrange(bound)
    results_si %$%
    lines(bound, avg_length - med_avg_length,
          col = cols[as.numeric(select)],
          lwd = 2)
  } # END for sel LOOP
          
  dev.off()
  
  pdf(file = paste0("Graphics_-_", inner_dir, "_", all_app, "-PCC.pdf"),
      width = 8, height = 6)
  
  # 2a. Classification Accuracy #
  with(results_s,{
    plot(x = bound, y = 1 - pcc, type = "p",
         ylim = c(0, .055),
         xlab = expression(theta[0]), ylab = "Percent Misclassified",
         main = "",
         pch  = pchs[as.numeric(select)],
         col  = cols[as.numeric(select)],
         cex = 1.5, lwd = 2, axes = FALSE)
    axis(1, col = "grey", at = unique(bound))
    axis(2, col = "grey", las = 1)
    mtext(oth_head[i])
    legend(x = "topleft", ncol = 2,
           legend = intersect(levels(select), unique(select)),
           pch    = pchs[which(levels(select) %in% unique(select))],
           col    = cols[which(levels(select) %in% unique(select))],
           cex    = 1,
           bty    = "n")
  })
  
  # 2b. Overlaying with Lines #
  for(sel in unique(results_s$select)){
    results_si <- subset(results_s, select == sel) %>%
                  unique %>%
                  arrange(bound)
    results_si %$%
    lines(bound, 1 - pcc,
          col = cols[as.numeric(select)],
          lwd = 2)
  } # END for sel LOOP
  
  dev.off()
} # END for i LOOP

setwd("..")


#####
# 3 # Conditional Graphs of All Conditions
#####

# Note: Use "2" to get sel and oth for conditions
bound_cond  <- 0

inner_dir <- "3Results-Conditional-Present"

dir.create(inner_dir, showWarnings = FALSE)
setwd(inner_dir)

for(i in seq_along(oth_cond)){
  red_cond  <- c(~select %in% sel_cond,
                 ~bound  %in% bound_cond,
                 oth_cond[[i]])
  all_cond  <- c(~select %in% unique(cond$select),
                 ~bound  %in% bound_cond,
                 oth_cond[[i]])
  all_app   <- oth_app[i]
  
  results_a <- filter_(results$conditional,
                       .dots = all_cond)
  results_s <- filter_(results$conditional,
                       .dots = red_cond) %>%
               merge(., ddply(results_a, "theta_int", summarize,
                              med_avg_length = median(avg_length),
                              med_pcc        = median(pcc))) %>%
               rbind(.[.$select %in% c("ELR"), ]) %>%
               mutate(theta = gsub(x = theta_int,
                                   pattern = "[([]",
                                   replace = "c\\(") %>%
                              gsub(pattern = "\\]",
                                   replace = "\\)") %>%
                              paste0("mean(", ., ")") %>%
                              sapply(FUN = function(text){
                                       eval(parse(text = text))
                                     }))
  
# Note: The last bit of code turns "(-0.2, 0]", into mean(c(-0.2, 0)) = .1.
#       First, turn "(-0.2, 0]" into c(-0.2, 0) (using gsub)
#       Second, add "mean(" to beginning and ")" to end.
#       Finally, evaluate the expression.
  
  pdf(file = paste0("Graphics_-_", inner_dir, "_", all_app, "-ATL.pdf"),
      width = 8, height = 6)
  
  # 1a. Plotting Average Test Length Deviance #
  with(results_s,{
    plot(x = theta, y = avg_length - med_avg_length, type = "p",
         ylim = c(-10, 10),
         xlab = expression(theta[k]), ylab = "Average Test Length Deviance",
         main = "",
         pch  = pchs[as.numeric(select)],
         col  = cols[as.numeric(select)],
         cex = 1.5, lwd = 2, axes = FALSE)
    abline(h = 0, lty = 2, lwd = 2, col = "lightgrey")
    abline(v = 0, lty = 2, lwd = 2, col = "lightgrey")
    axis(1, col = "grey", at = round(unique(theta), 1),
         cex.axis = .6)
    axis(2, col = "grey", las = 1)
    mtext(oth_head[i])
    legend(x = "topleft", ncol = 2,
           legend = intersect(levels(select), unique(select)),
           pch    = pchs[which(levels(select) %in% unique(select))],
           col    = cols[which(levels(select) %in% unique(select))],
           cex    = 1,
           bty    = "n")
  })
  
  # 1b. Overlaying with Lines #
  for(sel in unique(results_s$select)){
    results_si <- subset(results_s, select == sel) %>%
                  unique %>%
                  arrange(theta)
    results_si %$%
    lines(theta, avg_length - med_avg_length,
          col = cols[as.numeric(select)],
          lwd = 2)
  } # END for sel LOOP
  
  dev.off()
  
  pdf(file = paste0("Graphics_-_", inner_dir, "_", all_app, "-PCC.pdf"),
      width = 8, height = 6)
  
  # 2a. Classification Accuracy #
  with(results_s,{
    plot(x = theta, y = 1 - pcc, type = "p",
         ylim = c(0, .33),
         xlab = expression(theta[k]), ylab = "Percent Misclassified",
         main = "",
         pch  = pchs[as.numeric(select)],
         col  = cols[as.numeric(select)],
         cex = 1.5, lwd = 2, axes = FALSE)
    abline(v = 0, lty = 2, lwd = 2, col = "lightgrey")
    axis(1, col = "grey", at = round(unique(theta), 1),
         cex.axis = .6)
    axis(2, col = "grey", las = 1)
    mtext(oth_head[i])
    legend(x = "topleft", ncol = 2,
           legend = intersect(levels(select), unique(select)),
           pch    = pchs[which(levels(select) %in% unique(select))],
           col    = cols[which(levels(select) %in% unique(select))],
           cex    = 1,
           bty    = "n")
  })
  
  # 2b. Overlaying with Lines #
  for(sel in unique(results_s$select)){
    results_si <- subset(results_s, select == sel) %>%
                  unique %>%
                  arrange(theta)
    results_si %$%
    lines(theta, 1 - pcc,
          col = cols[as.numeric(select)],
          lwd = 2)
  } # END for sel LOOP
  
  dev.off()
} # END for i LOOP

setwd("..")


############################################
# 3. Simulation: Location of Selected Item #
############################################

#~~~~~~~~~~~~~~~~~~~~~#
# Simulation Function #
#~~~~~~~~~~~~~~~~~~~~~#

discCat <- function(cond, params){
  
#####
# B # (EXTRACTING PARTS OF SIMULATION)
#####
  
  # extracting the parameters/bound/select
  params_i <- params[[cond$par_cond]]
  bound_i  <- cond$bound
  theta_i  <- cond$theta
  select_i <- switch(as.character(cond$select),
                     `FI-bound`            = list(select = "UW-FI",      at = "bounds"),
                     `FI-ability`          = list(select = "UW-FI",      at = "theta"),
                     `FI-middle`           = list(select = "UW-FIM",     at = "bounds"),
                     `KL-bound`            = list(select = "FP-KL",      at = "bounds"),
                     `KL-estimated`        = list(select = "FP-EKL",     at = "bounds"),
                     `ELR`                 = list(select = "FP-ELR",     at = "bounds"),
                     `FI-ability-hybrid`   = list(select = "MX-FI/ELR",  at = "theta"),
                     `KL-estimated-hybrid` = list(select = "MX-EKL/ELR", at = "bounds"))
  
  # fixed stuff (delta and mx_sem)
  delta  <- 0.1
  mx_sem <- 0.5
  alpha  <- beta <- .05
  
#####
# B # (RUNNING MODEL)
#####
  
  ret  <- catIrt(params = params_i,
                 mod = "brm", theta = theta_i,
                 catStart  = list(n.start = 5, init.theta = 0,
                                  select = select_i$select, at = select_i$at,
                                  n.select = 1, delta = delta,
                                  score = "step", step.size = 1,
                                  range = c(-6, 6),
                                  mx_sem = mx_sem,
                                  leave.after.MLE = FALSE),
                 catMiddle = list(select = select_i$select, at = select_i$at,
                                  n.select = 1, delta = delta,
                                  score = "MLE",
                                  range = c(-6, 6),
                                  mx_sem = mx_sem),
                 catTerm   = list(term = "fixed", score = "MLE",
                                  n.min = 5, n.max = 150,
                                  c.term = list(bounds = bound_i)),
                                  progress = FALSE)
  
  ret <- ret$cat_indiv %>%
         setNames(., seq_along(.))
  
  ret <- ldply(ret, .id = "person",
               .fun = function(lst){
                 data.frame(item      = seq_along(lst$cat_resp),
                            cat_theta = lst$cat_theta[-1],
                            resp      = lst$cat_resp %>% unclass,
                            as.data.frame(lst$cat_params[ , c("a", "b", "c")]))
               })
  
  return(ret)                                
  
} # END discCat FUNCTION


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Generating Conditions: Params #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

## ITEMS ##
set.seed(34523453)

# conditions for parameters
par_bpar0 <- c("flat")
par_cpar0 <- sprintf("%.2f", c(0.25, 0.00))
par_size0 <- c(10000)
par_cond0 <- expand.grid(par_bpar = par_bpar0,
                         par_cpar = par_cpar0,
                         par_size = par_size0,
                         stringsAsFactors = FALSE) %>%
             mutate(par_cond = paste0(par_bpar, "_", par_cpar, "_", par_size))

# list to store parameters
params0   <- vector(mode = "list", length = nrow(par_cond0)) %>% 
             setNames(par_cond0$par_cond)

# generating parameters for each condition
for(i in 1:nrow(par_cond0)){
  par_cond_i <- par_cond0[i, ]
  par_bpar_i <- par_cond_i$par_bpar
  par_cpar_i <- par_cond_i$par_cpar
  par_size_i <- par_cond_i$par_size

  # as <- rlnorm(n = par_size_i,
  #              meanlog = .38, sdlog = .25)
  as <- 1
  bs <- runif(n = par_size_i,
              min = -4, max = 4)
  cs <- rep(as.numeric(par_cpar_i), par_size_i)
  
  params0[[i]] <- cbind(as, bs, cs)
  
} # END for i LOOP

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Generating Conditions: Other #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

cond_select0 <- c("FI-bound",
                  "FI-ability",
                  "FI-middle",
                  "KL-bound",
                  "KL-estimated",
                  "ELR",
                  "FI-ability-hybrid",
                  "KL-estimated-hybrid")

cond_bound0  <- 0
cond_theta0  <- c(-2, 2)

cond0 <- expand.grid(select = cond_select0,
                     bound  = cond_bound0,
                     theta  = cond_theta0,
                     stringsAsFactors = TRUE) %>%
         merge(par_cond0, ., by = NULL)

#~~~~~~~~~~~~~~~~~~~~#
# Running Conditions #
#~~~~~~~~~~~~~~~~~~~~#

results_disc <- ddply(cond0, .variables = names(cond0),
                      .fun = function(x){
                        discCat(x, params = params0) %>%
                        select(-person)
                      })

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Graphics for NCME/Paper Discussion #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

cols0 <- c("darkgoldenrod", "purple")

# everything but selection algorithms and bounds (corresponding numbers)
all_cond0   <- cond0[c("par_cpar", "theta", "select")]
all_cond0[] <- lapply(all_cond0, as.character)

# the appendix number (conditional number)
oth_app0  <- lapply(seq_along(all_cond0),
                    FUN = function(i){
                      x <- all_cond0[ , i]
                      match(x, unique(x))
                    }) %>%
             do.call(paste0, .)

# the header indicating bank conditions
oth_head0 <-   all_cond0 
oth_head0 %<>% setNames(gsub(pattern = ".*_(.*?)(par)*$",
                             replace = "\\1",
                             x = names(.),
                             perl = TRUE)) %>%
                apply(1,
                      FUN = function(x){
                        paste(names(.), x, sep = " = ", collapse = "; ")
                      })

# turning oth_cond into a formula to use with "select"
oth_cond0  <- lapply(1:nrow(all_cond0),
                     FUN = function(i){
                      paste0("~", names(all_cond0), "=='", as.character(all_cond0[i, ]), "'") %>%
                      lapply(as.formula)
                    })

inner_dir <- "4Discussion"

dir.create(inner_dir, showWarnings = FALSE)
setwd(inner_dir)

for(i in seq_along(oth_cond0)){
  all_cond0 <- oth_cond0[[i]]
  all_app0  <- oth_app0[i]
  
  results_d <- filter_(results_disc,
                       .dots = all_cond0)
  
  pdf(file = paste0("Graphics_-_", inner_dir, "_", all_app0, "-bpar.pdf"),
      width = 8, height = 6)
  
  # Plotting b-Value (Item Selected) for Algorithm #
  with(results_d, {
    
       # --> a. Plot hat(theta) after each item
       plot(x = item, y = cat_theta, type = "l",
            ylim = sort(unique(c(bound, theta))) + c(-1, 1),
            xlab = "CAT Item", ylab = expression(theta),
            col = cols0[1],
            lwd = 3, axes = FALSE)
    
       # --> b. Plot the b-parameter after/for each item
       lines(x = item, y = b, lwd = 3,
             col = cols0[2])
       
       # --> c. Draw a line at the bound and true theta
       abline(h = bound[1], lty = 2, lwd = 2, col = "grey")
       abline(h = theta[1], lty = 3, lwd = 2, col = "blue")
       
       # --> d. Add a note to indicate "theta" and "theta_0"
       text(x = max(item), y = c(bound[1], theta[1]) + .1,
            labels = expression(theta[0], theta[i]))
       
       # --> e. Add heading to plot
       mtext(oth_head0[i])
       
       # --> f. Draw axes to plot
       axis(1, col = "grey")
       axis(2, col = "grey", las = 1)
       
       # --> g. Add legend to represent stuffy stuff
       legend(x = c("topright", "bottomright")[(theta[1] > 0) + 1],
              legend = c(expression(hat(theta)),
                         expression(b)),
              lty    = 1,
              col    = cols0,
              bty    = "n")
      })
  
  dev.off()
  
} # END for i LOOP

setwd("..")
