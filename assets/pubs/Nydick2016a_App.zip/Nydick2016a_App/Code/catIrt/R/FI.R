FI <-
function( params, theta,
          type = c("expected", "observed"),
          resp = NULL ){
    
  UseMethod("FI")
    
} # END FI FUNCTION