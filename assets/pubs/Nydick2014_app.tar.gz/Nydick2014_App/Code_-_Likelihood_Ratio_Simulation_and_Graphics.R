###############################################
###############################################
## Code for SPRT and Binary IRT Models Paper ##
##                                           ##
## by Steven W. Nydick                       ##
## 2014-02-01                                ##
###############################################
###############################################

#############################
# Likelihood Ratio Graphics #
#############################

## SOURCING CAT SIMULATION FILES ##

# Must install/load modified catIrt package:
install.packages("catIrt_0.4-1.tar.gz", repos = NULL, source = TRUE)
library(catIrt)


############################################
# 1. The Log-Likelihood Ratio for One Item #
############################################

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Expected Derivative/Half Derivative/Maximum Functions #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

# We want code to calculate the expected derivative of the log-likelihood ratio
#  1) With one item and with multiple items,
#  2) With the left half and the right half,
#  3) Varying c, thet_0, thet, and delt

# p is the three parameter model with one (or multiple) item(s):
p <- function(a, b, ci, th){
	
  ci + (1 - ci)/( 1 + exp(-a*(th - b)) )
	
} # END p FUNCTION

# h.der is HALF of the likelihood ratio derivative:
h.der <- function(a, b, ci, t0, th, delt){
	
  lhalf <- p(a, b, 0, t0 + delt)*(1 - p(a, b, ci, th)/p(a, b, ci, t0 + delt))
  rhalf <- p(a, b, 0, t0 - delt)*(1 - p(a, b, ci, th)/p(a, b, ci, t0 - delt))
	
  return( list(lhalf = lhalf, rhalf = rhalf) )
	
} # END h.der FUNCTION

SPRT <- function(a, b, ci, t0, th, delta){
    
  {      p(a, b, ci, th)  * ( log( p(a, b, ci, t0 + delta) ) - log( p(a, b, ci, t0 - delta)) ) +
  	(1 - p(a, b, ci, th)) * ( log( (1 - p(a, b, ci, t0 + delta)) ) - log( (1 - p(a, b, ci, t0 - delta))) ) }
  	
} # END SPRT FUNCTION


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Expected Derivative/Half Derivative/Maximum Pictures  #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

#####
# 1 # (Varying thet0)
#####

# Note: Left Half  is theta_0 + delta
#       Right Half is theta_0 - delta

# Varying thet0, keeping a = 1, b = 0, c = .2, delt = .1, and thet = 2
x <- seq(-4, 1.9, by = .01)
y <- h.der(a = 1, b = 0, c = .2, t0 = x, th = 2, delt = .1)

# Now plotting each graph and the difference between them:
pdf(file = paste("Graphics_-_Likelihood_Ratio_Varying_Theta0.pdf", sep = ""), width = 9, height = 4.5 )
par(mfrow = c(1, 2))

# Half of the expected derivative of the log-likelihood function:
plot(x, y$lhalf, type = "l", lty = 3, lwd = 2,
     xlab = expression(theta[0]), ylab = "Evaluation",
     main = "Half of Expected log-Lik Derivative",
     xlim = c(-4, 2), ylim = c(-.4, 0),
     axes = FALSE)
mtext(expression(paste("a = 1; b = 0; c = .2; ", delta, " = .1; ", theta[i], " = 2", sep = "")))
lines(x, y$rhalf, lty = 2, lwd = 2, col = "black")
axis(1, col = "grey")
axis(2, col = "grey")
legend(x = "bottomleft", legend = c(expression(theta[0] + delta), expression(theta[0] - delta)),
       lty = c(2, 3), lwd = 2)

# The full derivative of the log-likelihood function:
plot(x, y$rhalf - y$lhalf, type = "l", lwd = 3,
     xlab = expression(theta[0]), ylab = "Expected Derivative",
     main = "Expected Derivative of the log-Lik Ratio",
     xlim = c(-4, 2), ylim = c(-.06, .05),
     axes = FALSE)
abline(h = 0, lty = 2, lwd = 2, col = "grey")
axis(1, col = "grey")
axis(2, col = "grey")

par(mfrow = c(1, 1))
dev.off()


#####
# 2 # (With Respect to b)
#####

x <- seq(0, 1, by = .01)
n <- length(x)
b1 <- sapply(x[-n], FUN = function(x) optimize(f = SPRT, interval = c(-4, 4), a = 1, t = -1, t0 = 0, ci = x, delta = .1, maximum = F)$min)
b2 <- sapply(x[-n], FUN = function(x) optimize(f = SPRT, interval = c(-4, 4), a = 1, t = +1, t0 = 0, ci = x, delta = .1, maximum = T)$max)
b3 <- sapply(x[-1], FUN = function(x) optimize(f = SPRT, interval = c(-4, 4), a = 1, t = -1, t0 = 0, ci = 0, delta = x,   maximum = F)$min)
b4 <- sapply(x[-1], FUN = function(x) optimize(f = SPRT, interval = c(-4, 4), a = 1, t = +1, t0 = 0, ci = 0, delta = x,   maximum = T)$max)

# Now plotting each graph and the difference between them:
pdf(file = paste("Graphics_-_Likelihood_Ratio_Maximum_B.pdf", sep = ""), width = 9, height = 9 )
par(mfcol = c(2, 2), mar = c(5, 5, 4, 2) + .1)

## 1 ## Varying c
plot(x[-n], b1, type = "l", lty = 1, lwd = 2,
     xlab = expression(c), ylab = expression(hat(b)),
     xlim = c(0, 1), ylim = c(-1, 1),
     axes = FALSE)
mtext(expression(paste(theta[i], " = -1; ", theta[0], " = 0; ", "a = 1; ", delta, "= .1", sep = "")))
abline(h = 0,  lty = 2, col = "grey40")
abline(h = -1, lty = 3, col = "grey40")
axis(1, col = "grey")
axis(2, col = "grey")

plot(x[-n], b2, type = "l", lty = 1, lwd = 2,
     xlab = expression(c), ylab = expression(hat(b)),
     xlim = c(0, 1), ylim = c(-1, 1),
     axes = FALSE)
mtext(expression(paste(theta[i], " = 1; ", theta[0], " = 0; ", "a = 1; ", delta, "= .1", sep = "")))
abline(h = 0, lty = 2, col = "grey40")
abline(h = 1, lty = 3, col = "grey40")
axis(1, col = "grey")
axis(2, col = "grey")

## 2 ## Varying delta
plot(x[-1], b3, type = "l", lty = 1, lwd = 2,
     xlab = expression(delta), ylab = expression(hat(b)),
     xlim = c(0, 1), ylim = c(-1, 1),
     axes = FALSE)
mtext(expression(paste(theta[i], " = -1; ", theta[0], " = 0; ", "a = 1; c = 0", sep = "")))
abline(h = 0,  lty = 2, col = "grey40")
abline(h = -1, lty = 3, col = "grey40")
axis(1, col = "grey")
axis(2, col = "grey")

plot(x[-1], b4, type = "l", lty = 1, lwd = 2,
     xlab = expression(delta), ylab = expression(hat(b)),
     xlim = c(0, 1), ylim = c(-1, 1),
     axes = FALSE)
mtext(expression(paste(theta[i], " = 1; ", theta[0], " = 0; ", "a = 1; c = 0", sep = "")))
abline(h = 0, lty = 2, col = "grey40")
abline(h = 1, lty = 3, col = "grey40")
axis(1, col = "grey")
axis(2, col = "grey")

par(mfrow = c(1, 1), mar = c(5, 4, 4, 2) + .1)
dev.off()


##########################################################
# 2. Simulation 2: Varying a and b with c = .5, .25 or 0 #
##########################################################

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Find Comparable Items Functions #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

p <- function(a, b, ci, th){

  expo <- exp(a*(th - b))
  ci + (1 - ci)/(1 + exp(-a*(th - b)))
  
} # END p FUNCTION

itemDif <- function(a1, b1, c1, a2, b2, c2){

  X <- seq(-6, 6, length.out = 100)
  Y <- ( p(a1, b1, c1, th = X) - p(a2, b2, c2, th = X) )^2 * dnorm(X)
  
  integrate.xy(x = X, fx = Y)
  
} # END itemDif FUNCTION


itemMatch <- function(a1, b1, c1, c2){

  i <- optim(par = c(1, 0), fn = function(x) itemDif(a1, b1, c1, x[1] + 6, x[2], c2),
             method = "L-BFGS-B", lower = -6, upper = 6)$par

  list(a2 = i[1] + 6, b2 = i[2], c2 = c2)

} # END itemMatch FUNCTION


#~~~~~~~~~~~~~~~~~~#
# Generating Items #
#~~~~~~~~~~~~~~~~~~#

# setwd("../../SPRT and 3PL IRT Models - Data/SPRT and 3PL IRT Models - Data 2013-11-14")

n <- 1000

set.seed(23434523)
a.par <- rlnorm(n = n, meanlog = .53, sdlog = .25)
b.par <- runif(n = n, min = -4, max = 4)
c.par <- .25

par1 <- cbind(a.par, b.par, c.par)
par2 <- t( apply(par1, MARGIN = 1, FUN = function(x, ci) unlist( itemMatch(x[1], x[2], x[3], c2 = ci) ), ci = .125) )
par3 <- t( apply(par2, MARGIN = 1, FUN = function(x, ci) unlist( itemMatch(x[1], x[2], x[3], c2 = ci) ), ci = 0) )
save(par1, par2, par3, file = "params.Rdata")


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Constructing Items and Persons #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

## ITEMS ##
load("params.Rdata")

## PERSONS ##
set.seed(9234723)
N      <- 10000
thetas <- rnorm(N)


#~~~~~~~~~~~~~~~~~~~~~~~#
# Generating Conditions #
#~~~~~~~~~~~~~~~~~~~~~~~#

c.par <- 1:3
c.t0  <- seq(-3, 3, by = 1.5)
c.at  <- c("theta", "bounds")

cond  <- expand.grid(par = c.par, t0 = c.t0, at = c.at, stringsAsFactors = FALSE)
numb  <- apply(cond, MARGIN = 2, FUN = function(x) match(x, unique(x)))

#~~~~~~~~~~~~~~~~~~~~#
# Parallel Functions #
#~~~~~~~~~~~~~~~~~~~~#

parCat <- function(ps, nps, cond, thetas, par1, par2, par3 ){

#####
# A # (SPECIFYING PROCESSOR THETAS)
#####

# N is the total number of people over all processors
  N <- length(thetas)
 
# thetas_ps is the thetas for the current processor 
  if( N %% nps == 0 ){
  	thetas_ps <- thetas[(N/nps * (ps - 1) + 1):(N/nps * ps)]
  } else{
    thetas_ps <- thetas[cut(1:N, nps, 1:nps, right = FALSE) == ps]
  } # END ifelse STATEMENT
  
#####
# B # (RUNNING MODEL AND RETURNING)
#####

  ret  <- catIrt(params = get(paste("par", cond[1], sep = "")),
                 mod = "brm", theta = thetas_ps,
                 catStart  = list(n.start = 4, init.theta = 0,
                                  select = "UW-FI", at = unlist(cond[3]),
                                  n.select = 1, delta = .1,
                                  score = "step", step.size = 1,
                                  range = c(-6, 6),
                                  leave.after.MLE = FALSE),
                 catMiddle = list(select = "UW-FI", at = unlist(cond[3]),
                                  n.select = 1, delta = .1,
                                  score = "MLE", range = c(-6, 6)),
                 catTerm   = list(term = "class", score = "MLE",
                                  n.min = 4, n.max = 200,
                                  c.term = list(method = "SPRT",
                                                bounds = unlist(cond[2]),
                                                categ = c(0, 1),
                                                delta = .1,
                                                alpha = .05, beta = .05)))

  return(ret)                                

} # END parCat Function


pCollect <- function(out){
	
# CAT Stuff:
  cat_categ  <- do.call( c,     lapply(out, FUN = function(x) x$cat_categ) )
  cat_length <- do.call( c,     lapply(out, FUN = function(x) x$cat_length) )
  cat_term   <- do.call( c,     lapply(out, FUN = function(x) x$cat_term) )

# Tot Stuff:
  tot_categ  <- do.call( c,     lapply(out, FUN = function(x) x$tot_categ) )

# True Stuff:
  true_categ  <- do.call( c,     lapply(out, FUN = function(x) x$true_categ) )
  full_params <- out[[1]]$full_params
  full_resp   <- do.call( rbind, lapply(out, FUN = function(x) x$full_resp) )
  mod         <- out[[1]]$mod

  ret <- list( cat_categ = cat_categ, cat_length = cat_length,     # CAT STUFF
               cat_term = cat_term,                                # CAT STUFF
               tot_categ = tot_categ,                              # TOT STUFF
               true_categ = true_categ,                            # TRUE STUFF
               full_params = full_params, full_resp = full_resp,   # FULL PARAMETERS/RESPONSES
               mod = mod )

  return(ret)

} # END pCollect FUNCTION


#~~~~~~~~~~~~~~~~~~~~#
# Running Simulation #
#~~~~~~~~~~~~~~~~~~~~#

# Set up libraries to run on cluster
library(snow)
library(Rmpi)
library(rlecuyer)

# Setting up a certain number of clusters:
nps <- 3
cl  <- makeMPIcluster(count = nps)

# Loading libraries on the clusters:
invisible( clusterEvalQ(cl, library(catIrt)) )
invisible( clusterEvalQ(cl, library(numDeriv)) )
invisible( clusterEvalQ(cl, library(sfsmisc)) )
invisible( clusterEvalQ(cl, library(rlecuyer)) )

set.seed(79023742)

seed <- round(runif(n = nrow(numb)) * 1000000)

for(i in 13:nrow(cond)){

# Setting up the random number generator:
  clusterSetupRNG(cl, type = "RNGstream", seed = seed[i])
  
# Running catMirt on a certain number of thetas on each cluster:
  out <- clusterApply( cl = cl, x = 1:nps, fun = parCat,
                       nps = nps, cond = cond[i, ],
                       thetas = thetas,
                       par1 = par1, par2 = par2, par3 = par3 )
                       
# Putting the output of clusterApply into a nice format:
  cat.i <- pCollect(out)

# And saving the output to a file:
  save(cat.i, file = paste("atSim", paste(numb[i, ], collapse = ""), ".Rdata", sep = ""))

  cat("Finished iters: ", i, ": ", date(), "\n", sep = "")
 
# Cleaning up: 
  rm(out, cat.i)
     
 } # END for i LOOP
 
stopCluster(cl)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Creating Simulation Plots #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~#

#####
# a # Aggregating data
#####

atTab <- apply(numb, MARGIN = 1, FUN = function(x){
	                               f <- paste("atSim", paste(x, collapse = ""), ".Rdata", sep = "") 	                                    
	                               load(f)
  	                               len <- mean(cat.i$cat_length)
  	                               acc <- mean(cat.i$cat_categ == cat.i$true_categ)
  	                               ls1 <- mean( 100*(cat.i$cat_categ != cat.i$true_categ) + cat.i$cat_length )
  	                               ls2 <- mean( 500*(cat.i$cat_categ != cat.i$true_categ) + cat.i$cat_length )
  	                               c(length = len, acc = acc, loss1 = ls1, loss2 = ls2)
  	                             }
  	           )
  	                
atTab <- data.frame(cond, t(atTab))
write.csv(atTab, file = "Results_-_atTab.csv", row.names = FALSE)

#####
# b # Creating test length plots
#####

pdf(file = "Graphics_-_atSim_Average_Test_Length_Simulation.pdf", width = 8, height = 8)
par(mfrow = c(2, 2))

############
# LENGTH #
############

## AT THETA ##
with(atTab, plot(x = t0[at == "theta"], y = length[at == "theta"], type = "p",
                 ylim = c(0, 200),
                 xlab = expression(theta[0]), ylab = "Average Test Length",
                 main = expression(paste("Maximum Fisher Info at ", hat(theta)[i], sep = "")),
                 pch = par[at == "theta"] + 15,
                 col = c("grey0", "grey25", "grey50")[ par[at == "theta"] ],
                 cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "topright", legend = c("c = .25", "c = .125", "c = 0"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)

## AT BOUND ##
with(atTab, plot(x = t0[at == "bounds"], y = length[at == "bounds"], type = "p",
                 ylim = c(0, 200),
                 xlab = expression(theta[0]), ylab = "Average Test Length",
                 main = expression(paste("Maximum Fisher Info at ", theta[0], sep = "")),
                 pch = par[at == "bounds"] + 15,
                 col = c("grey0", "grey25", "grey50")[ par[at == "theta"] ],
                 cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "topright", legend = c("c = .25", "c = .125", "c = 0"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)

############
# ACCURACY #
############

## AT THETA ##
with(atTab, plot(x = t0[at == "theta"], y = acc[at == "theta"], type = "p",
                 ylim = c(.95, 1),
                 xlab = expression(theta[0]), ylab = "Percent Classified Correctly",
                 main = expression(paste("Maximum Fisher Info at ", hat(theta)[i], sep = "")),
                 pch = par[at == "theta"] + 15,
                 col = c("grey0", "grey25", "grey50")[ par[at == "theta"] ],
                 cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "bottomright", legend = c("c = .25", "c = .125", "c = 0"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)

## AT BOUND ##
with(atTab, plot(x = t0[at == "bounds"], y = acc[at == "bounds"], type = "p",
                 ylim = c(.95, 1),
                 xlab = expression(theta[0]), ylab = "Percent Classified Correctly",
                 main = expression(paste("Maximum Fisher Info at ", theta[0], sep = "")),
                 pch = par[at == "bounds"] + 15,
                 col = c("grey0", "grey25", "grey50")[ par[at == "theta"] ],
                 cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "bottomright", legend = c("c = .25", "c = .125", "c = 0"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)

dev.off()


########################################################
# 3. Simulation 3: Checking FI, KL, and ELR at theta_0 #
########################################################

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Constructing Items and Persons #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

## ITEMS ##
load("params.Rdata")


## PERSONS ##
set.seed(234431)
N      <- 10000
thetas <- rnorm(N)


#~~~~~~~~~~~~~~~~~~~~~~~#
# Generating Conditions #
#~~~~~~~~~~~~~~~~~~~~~~~#

c.par  <- 1:3
c.t0   <- seq(-3, 3, by = 1.5)
c.sel  <- c("UW-FI", "FP-KL", "FP-ELR")
c.delt <- c(.1, .2)

cond  <- expand.grid(par = c.par, t0 = c.t0, select = c.sel, delt = c.delt, stringsAsFactors = FALSE)
numb  <- apply(cond, MARGIN = 2, FUN = function(x) match(x, unique(x)))


#~~~~~~~~~~~~~~~~~~~~#
# Parallel Functions #
#~~~~~~~~~~~~~~~~~~~~#

parCat <- function(ps, nps, cond, thetas, par1, par2, par3 ){

#####
# A # (SPECIFYING PROCESSOR THETAS)
#####

# N is the total number of people over all processors
  N <- length(thetas)
 
# thetas_ps is the thetas for the current processor 
  if( N %% nps == 0 ){
  	thetas_ps <- thetas[(N/nps * (ps - 1) + 1):(N/nps * ps)]
  } else{
    thetas_ps <- thetas[cut(1:N, nps, 1:nps, right = FALSE) == ps]
  } # END ifelse STATEMENT
  
#####
# B # (RUNNING MODEL AND RETURNING)
#####

  ret  <- catIrt(params = get(paste("par", cond[1], sep = "")),
                 mod = "brm", theta = thetas_ps,
                 catStart  = list(n.start = 4, init.theta = 0,
                                  select = unlist(cond[3]), at = "bounds",
                                  n.select = 1, delta = unlist(cond[4]),
                                  score = "step", step.size = 1,
                                  range = c(-6, 6),
                                  leave.after.MLE = FALSE),
                 catMiddle = list(select = unlist(cond[3]), at = "bounds",
                                  n.select = 1, delta = unlist(cond[4]),
                                  score = "MLE", range = c(-6, 6)),
                 catTerm   = list(term = "class", score = "MLE",
                                  n.min = 4, n.max = 200,
                                  c.term = list(method = "SPRT",
                                                bounds = unlist(cond[2]),
                                                categ = c(0, 1),
                                                delta = unlist(cond[4]),
                                                alpha = .05, beta = .05)))
                  
  return(ret)                                

} # END parCat Function


pCollect <- function(out){
	
# CAT Stuff:
  cat_categ  <- do.call( c,     lapply(out, FUN = function(x) x$cat_categ) )
  cat_length <- do.call( c,     lapply(out, FUN = function(x) x$cat_length) )
  cat_term   <- do.call( c,     lapply(out, FUN = function(x) x$cat_term) )

# Tot Stuff:
  tot_categ  <- do.call( c,     lapply(out, FUN = function(x) x$tot_categ) )

# True Stuff:
  true_categ  <- do.call( c,     lapply(out, FUN = function(x) x$true_categ) )
  full_params <- out[[1]]$full_params
  full_resp   <- do.call( rbind, lapply(out, FUN = function(x) x$full_resp) )
  mod         <- out[[1]]$mod

  ret <- list( cat_categ = cat_categ, cat_length = cat_length,     # CAT STUFF
               cat_term = cat_term,                                # CAT STUFF
               tot_categ = tot_categ,                              # TOT STUFF
               true_categ = true_categ,                            # TRUE STUFF
               full_params = full_params, full_resp = full_resp,   # FULL PARAMETERS/RESPONSES
               mod = mod )

  return(ret)

} # END pCollect FUNCTION


#~~~~~~~~~~~~~~~~~~~~#
# Running Simulation #
#~~~~~~~~~~~~~~~~~~~~#

# Set up libraries to run on cluster
library(snow)
library(Rmpi)
library(rlecuyer)

# Setting up a certain number of clusters:
nps <- 3
cl  <- makeMPIcluster(count = nps)

# Loading libraries on the clusters:
invisible( clusterEvalQ(cl, library(catIrt)) )
invisible( clusterEvalQ(cl, library(numDeriv)) )
invisible( clusterEvalQ(cl, library(sfsmisc)) )
invisible( clusterEvalQ(cl, library(rlecuyer)) )

set.seed(79023742)
seed <- round(runif(n = nrow(numb)) * 1000000)

for(i in 1:nrow(cond)){

# Setting up the random number generator:
  clusterSetupRNG(cl, type = "RNGstream", seed = seed[i])
  
# Running catMirt on a certain number of thetas on each cluster:
  out <- clusterApply( cl = cl, x = 1:nps, fun = parCat,
                       nps = nps, cond = cond[i, ],
                       thetas = thetas,
                       par1 = par1, par2 = par2, par3 = par3 )
                       
# Putting the output of clusterApply into a nice format:
  cat.i <- pCollect(out)

# And saving the output to a file:
  save(cat.i, file = paste("selSim", paste(numb[i, ], collapse = ""), ".Rdata", sep = ""))

  cat("Finished iters: ", i, ": ", date(), "\n", sep = "")
 
# Cleaning up: 
  rm(out, cat.i)
     
 } # END for i LOOP
 
stopCluster(cl)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~#
# Creating Simulation Plots #
#~~~~~~~~~~~~~~~~~~~~~~~~~~~#


#####
# a # Aggregating data
#####

selTab <- apply(numb, MARGIN = 1, FUN = function(x){
	                                f <- paste("selSim", paste(x, collapse = ""), ".Rdata", sep = "") 	                                    
	                                load(f)
  	                                len <- mean(cat.i$cat_length)
  	                                acc <- mean(cat.i$cat_categ == cat.i$true_categ)
  	                                ls1 <- mean( 100*(cat.i$cat_categ != cat.i$true_categ) + cat.i$cat_length )
  	                                ls2 <- mean( 500*(cat.i$cat_categ != cat.i$true_categ) + cat.i$cat_length )
  	                                c(length = len, acc = acc, loss1 = ls1, loss2 = ls2)
  	                             }
  	           )
  	                
selTab <- data.frame(cond, t(selTab))
write.csv(selTab, file = "Results_-_selTab.csv", row.names = FALSE)


#####
# b # Creating test length plots (delta = .1)
#####

pdf(file = "Graphics_-_selSim_Average_Test_Length_Simulation1.pdf", width = 20/3, height = 10)
par(mfcol = c(3, 2))

##########
# LENGTH #
##########

selTab1 <- subset(selTab, delt == .1)

## c = .25 ##
with(selTab1, plot(x = t0[par == 1], y = length[par == 1], type = "p",
                   ylim = c(0, 90),
                   xlab = expression(theta[0]), ylab = "Average Test Length",
                   main = expression(paste("c = .25", sep = "")),
                   pch = as.numeric(as.factor(select))[par == 1] + 15,
                   col = c("grey0", "grey25", "grey50")[ as.factor(select)[par == 1] ],
                   cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "topright", legend = c("Expected SPRT", "KL Divergence", "Fisher Information"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)

## c = .125 ##
with(selTab1, plot(x = t0[par == 2], y = length[par == 2], type = "p",
                   ylim = c(0, 90),
                   xlab = expression(theta[0]), ylab = "Average Test Length",
                   main = expression(paste("c = .125", sep = "")),
                   pch = as.numeric(as.factor(select))[par == 2] + 15,
                   col = c("grey0", "grey25", "grey50")[ as.factor(select)[par == 2] ],
                   cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "topright", legend = c("Expected SPRT", "KL Divergence", "Fisher Information"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)
       
     
## c = 0 ##
with(selTab1, plot(x = t0[par == 3], y = length[par == 3], type = "p",
                   ylim = c(0, 90),
                   xlab = expression(theta[0]), ylab = "Average Test Length",
                   main = expression(paste("c = 0", sep = "")),
                   pch = as.numeric(as.factor(select))[par == 3] + 15,
                   col = c("grey0", "grey25", "grey50")[ as.factor(select)[par == 3] ],
                   cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "topright", legend = c("Expected SPRT", "KL Divergence", "Fisher Information"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)


############
# ACCURACY #
############

## c = .25 ##
with(selTab1, plot(x = t0[par == 1], y = acc[par == 1], type = "p",
                   ylim = c(.95, 1),
                   xlab = expression(theta[0]), ylab = "Percent Classified Correctly",
                   main = expression(paste("c = .25", sep = "")),
                   pch = as.numeric(as.factor(select))[par == 1] + 15,
                   col = c("grey0", "grey25", "grey50")[ as.factor(select)[par == 1] ],
                   cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "bottomright", legend = c("Expected SPRT", "KL Divergence", "Fisher Information"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)

## c = .125 ##
with(selTab1, plot(x = t0[par == 2], y = acc[par == 2], type = "p",
                  ylim = c(.95, 1),
                  xlab = expression(theta[0]), ylab = "Percent Classified Correctly",
                  main = expression(paste("c = .125", sep = "")),
                  pch = as.numeric(as.factor(select))[par == 2] + 15,
                  col = c("grey0", "grey25", "grey50")[ as.factor(select)[par == 2] ],
                  cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "bottomright", legend = c("Expected SPRT", "KL Divergence", "Fisher Information"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)
       
     
## c = 0 ##
with(selTab1, plot(x = t0[par == 3], y = acc[par == 3], type = "p",
                   ylim = c(.95, 1),
                   xlab = expression(theta[0]), ylab = "Percent Classified Correctly",
                   main = expression(paste("c = 0", sep = "")),
                   pch = as.numeric(as.factor(select))[par == 3] + 15,
                   col = c("grey0", "grey25", "grey50")[ as.factor(select)[par == 3] ],
                   cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "bottomright", legend = c("Expected SPRT", "KL Divergence", "Fisher Information"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)

par(mfcol = c(1, 1))
dev.off()


#####
# b # Creating test length plots (delta = .2)
#####

pdf(file = "Graphics_-_selSim_Average_Test_Length_Simulation2.pdf", width = 20/3, height = 10)
par(mfcol = c(3, 2))

##########
# LENGTH #
##########

selTab2 <- subset(selTab, delt == .2)

## c = .25 ##
with(selTab2, plot(x = t0[par == 1], y = length[par == 1], type = "p",
                   ylim = c(0, 50),
                   xlab = expression(theta[0]), ylab = "Average Test Length",
                   main = expression(paste("c = .25", sep = "")),
                   pch = as.numeric(as.factor(select))[par == 1] + 15,
                   col = c("grey0", "grey25", "grey50")[ as.factor(select)[par == 1] ],
                   cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "topleft", legend = c("Expected SPRT", "KL Divergence", "Fisher Information"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)

## c = .125 ##
with(selTab2, plot(x = t0[par == 2], y = length[par == 2], type = "p",
                   ylim = c(0, 50),
                   xlab = expression(theta[0]), ylab = "Average Test Length",
                   main = expression(paste("c = .125", sep = "")),
                   pch = as.numeric(as.factor(select))[par == 2] + 15,
                   col = c("grey0", "grey25", "grey50")[ as.factor(select)[par == 2] ],
                   cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "topleft", legend = c("Expected SPRT", "KL Divergence", "Fisher Information"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)
       
     
## c = 0 ##
with(selTab2, plot(x = t0[par == 3], y = length[par == 3], type = "p",
                   ylim = c(0, 50),
                   xlab = expression(theta[0]), ylab = "Average Test Length",
                   main = expression(paste("c = 0", sep = "")),
                   pch = as.numeric(as.factor(select))[par == 3] + 15,
                   col = c("grey0", "grey25", "grey50")[ as.factor(select)[par == 3] ],
                   cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "topleft", legend = c("Expected SPRT", "KL Divergence", "Fisher Information"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)


############
# ACCURACY #
############

## c = .25 ##
with(selTab2, plot(x = t0[par == 1], y = acc[par == 1], type = "p",
                   ylim = c(.95, 1),
                   xlab = expression(theta[0]), ylab = "Percent Classified Correctly",
                   main = expression(paste("c = .25", sep = "")),
                   pch = as.numeric(as.factor(select))[par == 1] + 15,
                   col = c("grey0", "grey25", "grey50")[ as.factor(select)[par == 1] ],
                   cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "bottomright", legend = c("Expected SPRT", "KL Divergence", "Fisher Information"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)

## c = .125 ##
with(selTab2, plot(x = t0[par == 2], y = acc[par == 2], type = "p",
                  ylim = c(.95, 1),
                  xlab = expression(theta[0]), ylab = "Percent Classified Correctly",
                  main = expression(paste("c = .125", sep = "")),
                  pch = as.numeric(as.factor(select))[par == 2] + 15,
                  col = c("grey0", "grey25", "grey50")[ as.factor(select)[par == 2] ],
                  cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "bottomright", legend = c("Expected SPRT", "KL Divergence", "Fisher Information"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)
       
     
## c = 0 ##
with(selTab2, plot(x = t0[par == 3], y = acc[par == 3], type = "p",
                   ylim = c(.95, 1),
                   xlab = expression(theta[0]), ylab = "Percent Classified Correctly",
                   main = expression(paste("c = 0", sep = "")),
                   pch = as.numeric(as.factor(select))[par == 3] + 15,
                   col = c("grey0", "grey25", "grey50")[ as.factor(select)[par == 3] ],
                   cex = 1, lwd = 2, axes = FALSE) )
axis(1, at = c(-3, -1.5, 0, 1.5, 3), col = "grey")
axis(2, col = "grey")
legend(x = "bottomright", legend = c("Expected SPRT", "KL Divergence", "Fisher Information"),
       pch = 16:18, col = c("grey0", "grey25", "grey50"), cex = .8)

par(mfcol = c(1, 1))
dev.off()